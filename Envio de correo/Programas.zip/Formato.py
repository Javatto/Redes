html = '''
<html>
<body style="text-align: center;
            font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;">
    <h1 style="color:crimson;">
        Hubo un problema con una interfaz
    </h1>
        <p>El router R1 detecto una baja de la interfaz 0/0</p>
        <img src='cid:myimageid' width="200">
</body>
<footer style="font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
                text-align: center;">
    <rt></rt>
    <div>
        <p> -------------- Contacto --------------</p>
        <div style="padding-left: 20% ">
            <div style="float: left; 
                        height: 100px; 
                        width: 200px;  ">
                <p> Email de contacto</p>
                <p> traps.warning </p>
            </div>
            <div style="float: left; 
                        height: 100px; 
                        width: 200px; ">
                <p> Telefono de contacto</p>
                <p> 55-47-13-00-95</p>
            </div>
            <div style="float: left; 
                        height: 100px; 
                        width: 200px; ">
                <p> Pagina principal </p>
                <p> Flask </p>
            </div>
        </div>
    </div>
</footer>
</html>
    '''