import paramiko,json,time

def configurarSNMP():
   f = open("archivos/topologia.json")
   topologia = json.load(f)
   f.close()

   for router in topologia['routers']:

      conexion = paramiko.SSHClient()
      conexion.set_missing_host_key_policy(paramiko.AutoAddPolicy())
      conexion.connect(router['ip'],username=router['usuarios'][0][0],password=router['usuarios'][0][1],look_for_keys=False,allow_agent=False)
      nueva_conexion=conexion.invoke_shell()

      # CONFIGURACION DE SNMP-V3
      nueva_conexion.send("configure terminal\n")
      time.sleep(.3)
      nueva_conexion.send("snmp-server view miVista iso included\n")
      time.sleep(.3)
      nueva_conexion.send("snmp-server group miGrupo v3 priv read miVista\n")
      time.sleep(.3)
      nueva_conexion.send("snmp-server group miGrupo v3 priv write miVista\n")
      time.sleep(.3)  
      nueva_conexion.send("snmp-server user miUsuario miGrupo v3 auth sha miAuthPass priv des56 miPrivPass\n")
      time.sleep(.3)
      nueva_conexion.send("snmp-server community comun_pruebas RW\n")
      time.sleep(.3)
      nueva_conexion.send("snmp-server enable traps snmp linkdown linkup\n")
      time.sleep(.3)
      nueva_conexion.send("snmp-server host 192.168.0.10 version 2c comun_pruebas\n")
      time.sleep(.3)
      nueva_conexion.send("end\n")
      time.sleep(.3)

      nueva_conexion.close()