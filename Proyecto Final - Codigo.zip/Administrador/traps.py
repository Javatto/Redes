from pysnmp.entity import engine, config
from pysnmp.carrier.asyncore.dgram import udp
from pysnmp.entity.rfc3413 import ntfrcv
import monitoreo, correo

print("Analizando 192.168.1.10 en el puereto 162")
snmpEngine = engine.SnmpEngine()

config.addTransport(
   snmpEngine, udp.domainName + (1,),
   udp.UdpTransport().openServerMode(('192.168.0.10', 162))
)

config.addV1System(snmpEngine, 'vis_pruebas_read', 'comun_pruebas')

def cbFun(snmpEngine, stateReference, contextEngineId, contextName, varBinds, cbCtx):
   
   execContent = snmpEngine.observer.getExecutionContext('rfc3412.receiveMessage:request')
   ipEquipo = execContent['transportAddress'][0]
   nombreEquipo = monitoreo.getName(ipEquipo).split('=')[1]
   correoEquipo = monitoreo.getContact(ipEquipo).split('=')[1]

   for name,val in varBinds:
      if "Fast" in str(val):
         interfaz = str(val)

      if "Keep" in str(val):
         mensaje = "Trap activa en el router"+nombreEquipo+" se ha activado la interfaz "+interfaz
         accion = str(val)
      elif "down" in str(val):
         mensaje = "Trap activa en el router"+nombreEquipo+" se ha desactivado la interfaz "+interfaz
         accion = str(val)

   correo.enviarCorreo(accion,correoEquipo,mensaje)


ntfrcv.NotificationReceiver(snmpEngine, cbFun)
snmpEngine.transportDispatcher.jobStarted(1)  

try:
   snmpEngine.transportDispatcher.runDispatcher()
except:
   snmpEngine.transportDispatcher.closeDispatcher()
   raise