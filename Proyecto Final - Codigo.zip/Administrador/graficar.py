import pygal

def graficar_paquetes(interfaz):
    tiempo = []
    in_packets = []
    out_packets = []
    err_packets = []
    
    with open('archivos/analisis.txt', 'r') as f:
        for line in f.readlines():
            line = eval(line)

            tiempo.append(line['Tiempo'])
            in_packets.append(int(line['Fa'+interfaz+'_In_Packets']))
            err_packets.append(int(line['Fa'+interfaz+'_In_Error']))
            out_packets.append(int(line['Fa'+interfaz+'_Out_Packets']))

    graficarInPaq(tiempo,in_packets)
    graficarOutPaq(tiempo,out_packets)
    graficarErr(tiempo,err_packets)

def graficarInPaq(Tiempo,InPaq):    
    line_chart = pygal.Line(x_label_rotation=25)
    line_chart.title = "Paquetes de entrada"
    line_chart.x_labels = Tiempo
    line_chart.add('Paq. entrada', InPaq)
    line_chart.render_to_file('/home/javatt/Desktop/Administrador/static/grafInPaq.svg')

def graficarOutPaq(Tiempo,OutPaq):    
    line_chart = pygal.Line(x_label_rotation=25)
    line_chart.title = "Paquetes de salida"
    line_chart.x_labels = Tiempo
    line_chart.add('Paq. salida', OutPaq )
    line_chart.render_to_file('/home/javatt/Desktop/Administrador/static/grafOutPaq.svg')

def graficarErr(Tiempo,Err):    
    line_chart = pygal.Line(x_label_rotation=25)
    line_chart.title = "Paquetes con errores"
    line_chart.x_labels = Tiempo
    line_chart.add('Paq. errores', Err )
    line_chart.render_to_file('/home/javatt/Desktop/Administrador/static/grafErr.svg')
