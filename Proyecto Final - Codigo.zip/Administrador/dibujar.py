import networkx as nx, matplotlib.pyplot as plt, json

def dibujarTopologia():
   f = open("archivos/topologia.json")
   topologia = json.load(f)
   f.close()


   plt.clf() 
   G = nx.Graph()
   for router in topologia['routers']:
       G.add_node(router["router"])

   for r1 in topologia['routers']: 
      for r2 in r1["vecinos"]:
         if r2 != "ISP":
            G.add_edge(r1["router"], r2)

   nx.draw_networkx(G, with_labels=True)
   plt.savefig("static/topologia.jpg")
   