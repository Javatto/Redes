from pysnmp.hlapi import *
from pysnmp.entity.rfc3413.oneliner import cmdgen
from datetime import datetime
import time,os, correo

auth = UsmUserData(
      userName= 'miUsuario',
      authKey='miAuthPass',
      authProtocol= usmHMACSHAAuthProtocol,
      privKey='miPrivPass',
      privProtocol=usmDESPrivProtocol
)

def monitorear(ip,interfaz,tiempo):

      if os.path.exists("archivos/analisis.txt"):
            os.remove("archivos/analisis.txt")
         
      tmpData = [0,0,0]
      idInterfaz = getInterfaz(interfaz)
      i = 1

      while( i != 41):
         result = {}

         if i%2 == 0:
            result['Tiempo'] = datetime.now().strftime('%I:%M:%S')
            result['Fa'+interfaz+'_In_Packets'] = int(getInPaq(idInterfaz,ip))-tmpData[0]
            result['Fa'+interfaz+'_In_Error'] = int(getInErr(idInterfaz,ip))-tmpData[1]
            result['Fa'+interfaz+'_Out_Packets'] = int(getOutPaq(idInterfaz,ip))-tmpData[2]
            if int(getInErr(idInterfaz,ip)) > tmpData[1]:
                  contacto = getContact(ip).split("=")[1]
                  if contacto != " ":
                        correo.enviarCorreo('Paquetes danados',contacto,"Alerta activada, se supero un nivel de errores con respecto a un valor anterior en el router"+getName(ip).split("=")[1])
                  else:
                        print("No se tiene un correo configurado para mandar la alerta")
            with open('archivos/analisis.txt', 'a') as f:
               f.write(str(result)+"\n")
               f.close()

         else:
            tmpData[0] = int(getInPaq(idInterfaz,ip))
            tmpData[1] = int(getInErr(idInterfaz,ip))
            tmpData[2] = int(getOutPaq(idInterfaz,ip))
                  
         i = i+1
         time.sleep(tiempo)
      
def getInterfaz(interfaz):
      if interfaz == "0/0":
            return 1
      elif interfaz == "1/0":
            return 2
      elif interfaz == "1/1":
            return 3
      elif interfaz == "2/0":
            return 4
      elif interfaz == "2/1":
            return 5
      else: 
            return 10

def getInPaq(interfaz,ip):
    iterator = getCmd(
          SnmpEngine(),
          auth,
          UdpTransportTarget((ip,161)),
          ContextData(),
          ObjectType(ObjectIdentity(".1.3.6.1.2.1.2.2.1.11."+str(interfaz)))
    )
    errorIndication,errorStatus,errorIndex,varBinds = next(iterator)
    salida = str(varBinds[0]).replace(" ","").split("=")
    return salida[1]

def getInErr(interfaz,ip):
    iterator = getCmd(
          SnmpEngine(),
          auth,
          UdpTransportTarget((ip,161)),
          ContextData(),
          ObjectType(ObjectIdentity(".1.3.6.1.2.1.2.2.1.14."+str(interfaz)))
    )
    errorIndication,errorStatus,errorIndex,varBinds = next(iterator)
    salida = str(varBinds[0]).replace(" ","").split("=")
    return salida[1]

def getOutPaq(interfaz,ip):
    iterator = getCmd(
          SnmpEngine(),
          auth,
          UdpTransportTarget((ip,161)),
          ContextData(),
          ObjectType(ObjectIdentity(".1.3.6.1.2.1.2.2.1.17."+str(interfaz)))
    )
    errorIndication,errorStatus,errorIndex,varBinds = next(iterator)
    salida = str(varBinds[0]).replace(" ","").split("=")
    return salida[1]

def getName(ip):
      iterator = getCmd(
            SnmpEngine(),
            auth,
            UdpTransportTarget((ip,161)),
            ContextData(),
            ObjectType(ObjectIdentity('SNMPv2-MIB','sysName',0))
      )
      errorIndication,errorStatus,errorIndex,varBinds = next(iterator)
      return str(varBinds[0])

def getContact(ip):
      iterator = getCmd(
            SnmpEngine(),
            auth,
            UdpTransportTarget((ip,161)),
            ContextData(),
            ObjectType(ObjectIdentity('SNMPv2-MIB','sysContact',0))
      )
      errorIndication,errorStatus,errorIndex,varBinds = next(iterator)
      return str(varBinds[0])

def setNombre(ip,valor):
      iterator = setCmd(
            SnmpEngine(),
            auth,
            UdpTransportTarget((ip,161)),
            ContextData(),
            ObjectType(ObjectIdentity('SNMPv2-MIB','sysName',0),valor)
      )
      errorIndication,errorStatus,errorIndex,varBinds = next(iterator)
      contacto = getContact(ip).split("=")[1]
      nombre = getName(ip).split("=")[1]
      if contacto != "":
            correo.enviarCorreo('Cambio de nombre',contacto,"Alerta activada, se ha modificado el nombre del router"+nombre+" desde la MIB")
      else:
            print("No se tiene un correo configurado para mandar la alerta")
      return str(varBinds[0])

def setContact(ip,valor):
      iterator = setCmd(
            SnmpEngine(),
            auth,
            UdpTransportTarget((ip,161)),
            ContextData(),
            ObjectType(ObjectIdentity('SNMPv2-MIB','sysContact',0),valor)
      )
      errorIndication,errorStatus,errorIndex,varBinds = next(iterator)
      contacto = getContact(ip).split("=")[1]
      nombre = getName(ip).split("=")[1]
      if contacto != "":
            correo.enviarCorreo('Cambio de contacto',contacto,"Alerta activada, se ha modificado el contacto del router"+nombre+" desde la MIB")
      else:
            print("No se tiene un correo configurado para mandar la alerta")
      return str(varBinds[0])

def setLocalizacion(ip,valor):
      iterator = setCmd(
            SnmpEngine(),
            auth,
            UdpTransportTarget((ip,161)),
            ContextData(),
            ObjectType(ObjectIdentity('SNMPv2-MIB','sysLocation',0),valor)
      )
      errorIndication,errorStatus,errorIndex,varBinds = next(iterator)
      contacto = getContact(ip).split("=")[1]
      nombre = getName(ip).split("=")[1]
      if contacto != "":
            correo.enviarCorreo('Cambio de localizacion',contacto,"Alerta localizacion, se ha modificado el contacto del router"+nombre+" desde la MIB")
      else:
            print("No se tiene un correo configurado para mandar la alerta")
      return str(varBinds[0])
