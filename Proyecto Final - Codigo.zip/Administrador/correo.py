from email.message import EmailMessage
import smtplib

def enviarCorreo(asunto,correo,mensaje): 

   email = EmailMessage()
   email["From"] = "traps.warning@gmail.com"
   email["To"] = correo
   email["Subject"] = asunto
   email.set_content(mensaje)

   print(email.as_string())
   #smtp = smtplib.SMTP_SSL("smtp.gmail.com")
   #smtp.login("traps.warning@gmail.com","nrfjfnwuxdvjbsrc")
   #smtp.sendmail("traps.warning@gmail.com",correo,email.as_string())
   #smtp.quit()