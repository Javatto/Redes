import pexpect,time

def configurarSSH(ip,name,user,passw):
   
   if name == "ISP":
      return

   print("El router "+name+" no tiene configurado SSH, se configurara a continuacion...")

   child = pexpect.spawn('telnet '+ip)
   child.expect('Username: ')
   child.sendline(user)
   child.expect('Password: ')
   child.sendline(passw)

   child.expect(name+"#")
   child.sendline("configure terminal")
   child.expect(["Enter configuration commands, one per line.  End with CNTL/Z",name+"(config)#"])
   child.sendline("ip ssh rsa keypair-name sshkey")
   child.expect_exact("Please create RSA keys (of atleast 768 bits size) to enable SSH v2.\r\n"+name+"(config)#")
   child.sendline("ip ssh version 2")
   child.expect_exact(name+"(config)#")
   child.sendline("ip ssh time-out 30")
   child.expect_exact(name+"(config)#")
   child.sendline("ip ssh authentication-retries 3")
   child.expect_exact(name+"(config)#")
   child.sendline("crypto key generate rsa usage-keys label sshkey modulus 1024")
   time.sleep(1)
   child.close()
   print("  --SSH se ha configurado correctamente")