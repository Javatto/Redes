import paramiko,time,telnetSSH,json

topologia = {}
routers = []
nombres = [] 

def buscarVecinos(ip,name,user,passw):
   if name in nombres or name == "ISP":
      return
   
   conectados=[]
   interfaces = []

   try: 
      conexion = paramiko.SSHClient()
      conexion.set_missing_host_key_policy(paramiko.AutoAddPolicy())
      conexion.connect(ip,username=user,password=passw,look_for_keys=False,allow_agent=False)
      nueva_conexion=conexion.invoke_shell()

      nueva_conexion.send("show cdp ne | section Fas\n")
      time.sleep(.5)
      vecinos = str(nueva_conexion.recv(50000))

      for linea in vecinos.split("\\r\\n"):
         auxCon = linea.split()
         if "7206VXR" in auxCon:
            conectados.append(auxCon[0])

      for x in vecinos.replace("\\r\\n"," ").split():
         if ("/" in x) and (x not in interfaces):
            interfaces.append(x)

      routers.append({"router":name,"ip":ip, "usuarios":[(user, passw)], "vecinos": conectados, "interfaces": interfaces})
      nombres.append(name)

      for dispositivo in conectados:
         nueva_conexion.send("sh cdp entry "+dispositivo+"\n")
         time.sleep(.5)
         vecinos = str(nueva_conexion.recv(50000))
         info_dispositivo = vecinos.replace("\\r\\n"," ").split()

         indice = info_dispositivo.index("address:")
         buscarVecinos(info_dispositivo[indice+1],dispositivo,user,passw)
         
      nueva_conexion.close()
      conexion.close()

   except paramiko.ssh_exception.NoValidConnectionsError as e:
      telnetSSH.configurarSSH(ip,name,user,passw)
      time.sleep(2)
      buscarVecinos(ip,name,user,passw)


   topologia['routers'] = routers 
   return topologia

def escanear(ip,name,user,passw):
   nuevaTopologia = buscarVecinos(ip,name,user,passw)
   with open("archivos/topologia.json","w") as outfile:
      json.dump(nuevaTopologia,outfile)
      outfile.close()
   nombres.clear()
   topologia.clear()
   routers.clear()




