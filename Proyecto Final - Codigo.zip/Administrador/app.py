from flask import Flask, json , render_template, request
import topologia as scriptTopologia, dibujar, monitoreo, usuarios, graficar, confSNMP, os, protocolos

comand= " python3 /home/javatt/Desktop/Administrador/traps.py "

app= Flask(__name__)

@app.route("/")
def index():
   return "Administrador de red"

@app.route("/traps")
def traps():
   os.popen("sudo -S %s"%(comand), 'w').write("1532")
   return "Monitoreando por traps"

########################## Topologia
@app.route("/levanta/protocolos")
def levantarProtocolos():

   protocolos.configurar()
   return "Se han levantado todos los protocolos"

@app.route("/baja/protocolos/<protocolo>")
def bajaProtocolos(protocolo):

   protocolos.desconfigurar(protocolo)
   return "Se han dado de baja los demas protocolos menos "+protocolo

@app.route("/topologia/escanear")
def escanearTopologia():

   scriptTopologia.escanear("192.168.0.1","R5","admin","root")
         
   return "Se ha escaneado la red, puede revisarla en /topologia/mostrar"

@app.route("/topologia/mostrar")
def mostrarTopologia():
   f = open("archivos/topologia.json")
   topologia = json.load(f)
   f.close()
   return json.jsonify(topologia)

@app.route("/topologia/dibujar")
def dibujarTopologia():
   dibujar.dibujarTopologia()         
   return render_template("topologia.html")

########################## Usuarios Globales
@app.route("/usuarios/global/crear/<nombre>/<contrasena>/<privilegios>")
def cUsuarioGlobal(nombre,contrasena,privilegios):
   return json.jsonify(usuarios.crearUsuarioGlobal(nombre,contrasena,int(privilegios)))

@app.route("/usuarios/global/modificar/<nombre>/<contrasena>/<privilegios>")
def mUsuarioGlobal(nombre,contrasena,privilegios):
   return json.jsonify(usuarios.modUsuarioGlobal(nombre,contrasena,int(privilegios)))

@app.route("/usuarios/global/eliminar/<nombre>")
def eUsuarioGlobal(nombre):
   return json.jsonify(usuarios.elimUsuarioGlobal(nombre))

##########################  Usuarios locales
@app.route("/usuarios/crear/<ip>/<nombre>/<contrasena>/<privilegios>")
def cUsuarioLocal(ip,nombre,contrasena,privilegios):
   return json.jsonify(usuarios.crearUsuario(ip,nombre,contrasena,int(privilegios)))

@app.route("/usuarios/modificar/<ip>/<nombre>/<contrasena>/<privilegios>")
def mUsuarioLocal(ip,nombre,contrasena,privilegios):
   return json.jsonify(usuarios.modUsuario(ip,nombre,contrasena,int(privilegios)))

@app.route("/usuarios/eliminar/<ip>/<nombre>")
def eUsuarioLocal(ip,nombre):
   return json.jsonify(usuarios.elimUsuario(ip,nombre))

########################## Monitorear
@app.route("/monitorear")
def monitorearInterfaz():
   monitoreo.monitorear(request.args.get("ip"),request.args.get("interfaz"),int(request.args.get("tiempo")))       
   graficar.graficar_paquetes(request.args.get("interfaz"))

   return render_template("monitoreo.html")

######################## SNMPV3

@app.route("/configurar/snmp")
def confgurarSNMPV3():
   confSNMP.configurarSNMP()
   return "Se ha configurado snmp en todos los Routers"

@app.route("/modificar/nombre/<ip>/<nombreNuevo>")
def modificarNombre(ip,nombreNuevo):
   return monitoreo.setNombre(ip,nombreNuevo)

@app.route("/modificar/contacto/<ip>/<contacto>")
def modificarContacto(ip,contacto):
   return monitoreo.setContact(ip,contacto)

@app.route("/modificar/localizacion/<ip>/<localizacion>")
def modificarLocalizacion(ip,localizacion):
   return monitoreo.setLocalizacion(ip,localizacion)

if __name__ == '__main__':
   app.run()
