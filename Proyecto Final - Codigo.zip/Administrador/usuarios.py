import paramiko,time,json

def crearUsuarioGlobal(usuario,password,privilegios):
   f = open("archivos/topologia.json")
   topologia = json.load(f)
   f.close()

   for router in topologia['routers']:

      router['usuarios'].append([usuario,password])

      conexion = paramiko.SSHClient()
      conexion.set_missing_host_key_policy(paramiko.AutoAddPolicy())
      conexion.connect(router['ip'],username="admin",password="root",look_for_keys=False,allow_agent=False)
      nueva_conexion=conexion.invoke_shell()
      nueva_conexion.send("configure terminal\n")
      time.sleep(.5)
      nueva_conexion.send("user "+usuario+" privilege "+str(privilegios)+" secret "+password+"\n")
      time.sleep(.5)
      nueva_conexion.send("end\n")
      nueva_conexion.close()

   with open("archivos/topologia.json","w") as outfile:
      json.dump(topologia,outfile)
      outfile.close()

   return topologia

def modUsuarioGlobal(usuario,nuevaPassword,privilegios):

   if usuario == "admin":
      return "NO se puede modificar este usuario"

   f = open("archivos/topologia.json")
   topologia = json.load(f)
   f.close()
   indice = 0

   for router in topologia['routers']:
      for i in range(len(router['usuarios'])):
         if usuario == router['usuarios'][i][0]:
            indice = i

      router['usuarios'][indice] = [usuario,nuevaPassword]
         
      conexion = paramiko.SSHClient()
      conexion.set_missing_host_key_policy(paramiko.AutoAddPolicy())
      conexion.connect(router['ip'],username="admin",password="root",look_for_keys=False,allow_agent=False)
      nueva_conexion=conexion.invoke_shell()

      nueva_conexion.send("configure terminal\n")
      time.sleep(.5)
      nueva_conexion.send("user "+usuario+" privilege "+str(privilegios)+" secret "+nuevaPassword+"\n")
      time.sleep(.5)
      nueva_conexion.send("end\n")
      nueva_conexion.close()

   with open("archivos/topologia.json","w") as outfile:
      json.dump(topologia,outfile)

   return topologia

def elimUsuarioGlobal(usuario):

   if usuario == "admin":
      return "NO se puede eliminar este usuario"

   f = open("archivos/topologia.json")
   topologia = json.load(f)
   f.close()
   indice = 0

   for router in topologia['routers']:
      for i in range(len(router['usuarios'])):
         if usuario == router['usuarios'][i][0]:
            indice = i
         
      conexion = paramiko.SSHClient()
      conexion.set_missing_host_key_policy(paramiko.AutoAddPolicy())
      conexion.connect(router['ip'],username="admin",password="root",look_for_keys=False,allow_agent=False)
      nueva_conexion=conexion.invoke_shell()

      nueva_conexion.send("configure terminal\n")
      time.sleep(.5)
      nueva_conexion.send("no user "+router['usuarios'][indice][0]+"\n")
      time.sleep(.5)
      nueva_conexion.send("end\n")
      nueva_conexion.close()

      router['usuarios'].pop(indice)

   with open("archivos/topologia.json","w") as outfile:
      json.dump(topologia,outfile)

   return topologia

def crearUsuario(ip,usuario,password,privilegios):
   f = open("archivos/topologia.json")
   topologia = json.load(f)
   f.close()
   indice = 0

   for router in topologia['routers']:
      if ip == router['ip']:
         router['usuarios'].append([usuario,password])
         break

   
   conexion = paramiko.SSHClient()
   conexion.set_missing_host_key_policy(paramiko.AutoAddPolicy())
   conexion.connect(ip,username="admin",password="root",look_for_keys=False,allow_agent=False)
   nueva_conexion=conexion.invoke_shell()
   nueva_conexion.send("configure terminal\n")
   time.sleep(.5)
   nueva_conexion.send("user "+usuario+" privilege "+str(privilegios)+" secret "+password+"\n")
   time.sleep(.5)
   nueva_conexion.send("end\n")
   nueva_conexion.close()
         
   with open("archivos/topologia.json","w") as outfile:
      json.dump(topologia,outfile)

   return topologia

def modUsuario(ip,usuario,nuevaPassword,privilegios):

   if usuario == "admin":
      return "NO se puede modificar este usuario"

   f = open("archivos/topologia.json")
   topologia = json.load(f)
   f.close()
   indice = 0

   for router in topologia['routers']:
      if ip == router['ip']:
         for i in range(len(router['usuarios'])):
            if usuario == router['usuarios'][i][0]:
               indice = i
               break
         break

   router['usuarios'][indice] = [usuario,nuevaPassword]
   
   conexion = paramiko.SSHClient()
   conexion.set_missing_host_key_policy(paramiko.AutoAddPolicy())
   conexion.connect(ip,username="admin",password="root",look_for_keys=False,allow_agent=False)
   nueva_conexion=conexion.invoke_shell()
   nueva_conexion.send("configure terminal\n")
   time.sleep(.5)
   nueva_conexion.send("user "+usuario+" privilege "+str(privilegios)+" secret "+nuevaPassword+"\n")
   time.sleep(.5)
   nueva_conexion.send("end\n")
   nueva_conexion.close()
         
   with open("archivos/topologia.json","w") as outfile:
      json.dump(topologia,outfile)

   return topologia

def elimUsuario(ip,usuario):

   if usuario == "admin":
      return "NO se puede eliminar este usuario"

   f = open("archivos/topologia.json")
   topologia = json.load(f)
   f.close()
   indice = 0

   for router in topologia['routers']:
      if ip == router['ip']:
         for i in range(len(router['usuarios'])):
            if usuario == router['usuarios'][i][0]:
               indice = i
               break
         break
         
         
   conexion = paramiko.SSHClient()
   conexion.set_missing_host_key_policy(paramiko.AutoAddPolicy())
   conexion.connect(ip,username="admin",password="root",look_for_keys=False,allow_agent=False)
   nueva_conexion=conexion.invoke_shell()

   nueva_conexion.send("configure terminal\n")
   time.sleep(.5)
   nueva_conexion.send("no user "+router['usuarios'][indice][0]+"\n")
   time.sleep(.5)
   nueva_conexion.send("end\n")
   nueva_conexion.close()

   router['usuarios'].pop(indice)

   with open("archivos/topologia.json","w") as outfile:
      json.dump(topologia,outfile)

   return topologia
